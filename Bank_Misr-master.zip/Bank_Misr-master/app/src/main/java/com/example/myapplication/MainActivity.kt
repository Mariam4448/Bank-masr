package com.example.myapplication

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import java.util.Locale


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    LoginDesign(Modifier.padding(innerPadding))
                }
            }
        }
    }
}


@Composable
fun LoginDesign(modifier: Modifier = Modifier) {

    val context = LocalContext.current
    var usernameField by rememberSaveable { mutableStateOf("") }
    var passwordField by rememberSaveable { mutableStateOf("") }
    var passwordVisibility by rememberSaveable { mutableStateOf(false) }
    val icon =
        if (passwordVisibility) painterResource(R.drawable.visibility)
        else painterResource(R.drawable.visibility_off)
    val isFormValid = usernameField.isNotBlank() && passwordField.isNotBlank()
    val coulor = if (isFormValid) Color(0xFFBE3547) else Color(0xFFEDCFD3)

    Column(
        modifier = modifier
            .padding(start = 24.dp, top = 32.dp, end = 24.dp)

    ) {

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {

            Image(
                painter = painterResource(id = R.drawable.bm_icon),
                contentDescription = "logo",
                modifier = Modifier.size(120.dp)
            )

            Text(
                text = stringResource(R.string.lang),
                fontSize = 24.sp,
                fontFamily = FontFamily(Font(R.font.cairo)),
                fontWeight = FontWeight.Bold,
                color = Color(197, 68, 85, 255),
                modifier = Modifier.clickable {
                    switchLanguage(context)
                }
            )
        }

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = usernameField,
            onValueChange = { usernameField = it },
            label = {
                Text(text = stringResource(R.string.username))
            }
        )

        OutlinedTextField(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            value = passwordField,
            onValueChange = { passwordField = it },
            label = {
                Text(text = stringResource(R.string.password1))
            },
            trailingIcon = {
                IconButton(onClick = { passwordVisibility = !passwordVisibility }) {
                    Icon(icon, contentDescription = "")
                }
            },
            visualTransformation =
                if (passwordVisibility) VisualTransformation.None
                else PasswordVisualTransformation()
        )

        Text(
            text = stringResource(R.string.forgetten),
            textDecoration = TextDecoration.Underline,
            modifier = Modifier.padding(top = 20.dp)
        )

        Button(
            onClick = {},
            colors = ButtonDefaults.buttonColors(
                contentColor = Color.White,
                containerColor = coulor
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 28.dp)
        ) {
            Text(text = stringResource(R.string.login))
        }

        Text(
            modifier = Modifier.padding(top = 20.dp),
            text = buildAnnotatedString {
                append(stringResource(R.string.need_help))
                withLink(
                    LinkAnnotation.Url(
                        "https://developer.android.com/",
                        styles = TextLinkStyles(
                            style = SpanStyle(
                                color = Color(197, 78, 94, 255),
                                textDecoration = TextDecoration.Underline,
                                fontWeight = FontWeight.Bold
                                )
                        )
                    )
                )
                { append(stringResource(R.string.contact)) }
            }
        )

        HorizontalDivider(modifier = Modifier.padding(top = 40.dp))

        Imagess()
    }
}

fun switchLanguage(context: Context) {
    val currentLocale = context.resources.configuration.locales[0]
    val newLocale = if (currentLocale.language == "ar") {
        Locale("en")
    } else {
        Locale("ar")
    }

    val prefs = context.getSharedPreferences("Settings", Context.MODE_PRIVATE)
    prefs.edit().putString("language", newLocale.language).apply()

    setLocale(context, newLocale)

    // إعادة تشغيل الـ Activity
    (context as? ComponentActivity)?.recreate()
}

fun setLocale(context: Context, locale: Locale) {
    Locale.setDefault(locale)
    val config = Configuration(context.resources.configuration)
    config.setLocale(locale)
    context.resources.updateConfiguration(config, context.resources.displayMetrics)
}

@Composable
fun Imagess(modifier: Modifier = Modifier) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
    ) {
        Image(
            painterResource(R.drawable.our_products),
            contentDescription = "",
            modifier = Modifier.size(60.dp)
        )
        Image(
            painterResource(R.drawable.exchange_rate),
            contentDescription = "",
            modifier = Modifier.size(60.dp)
        )
        Image(
            painterResource(R.drawable.security_tips),
            contentDescription = "",
            modifier = Modifier.size(60.dp)
        )
        Image(
            painterResource(R.drawable.nearest_branch_or_atm),
            contentDescription = "",
            modifier = Modifier.size(60.dp)
        )
    }
}

@Preview(showSystemUi = true, showBackground = false)
@Composable
private fun LoginDesignPreview() {
    LoginDesign()
}